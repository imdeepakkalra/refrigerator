﻿// See https://aka.ms/new-console-template for more information

using RefrigeratorApp.Models;
List<Product> lisProducts = new List<Product>();
insertProduct();
supportexpireProduct();


Console.WriteLine("Press any key to continue");
Console.ReadKey();


void insertProduct()
{
    try
    { 
        Product product = new Product();
        Console.WriteLine("Enter the product id");
        product.ProductId = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter the product name");
        product.ProductName = Console.ReadLine();
        Console.WriteLine("Enter the product quantity");
        product.Quantity = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter the product consumption");
        product.Consumption = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter the product purchase date");
        product.PurchaseDate = Convert.ToDateTime(Console.ReadLine());
        Console.WriteLine("Enter the product expiration date");
        product.ExpirationDate = Convert.ToDateTime(Console.ReadLine());
       
        lisProducts.Add(product);
        

       
        Console.WriteLine("Product inserted successfully");
    
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
}
void supportexpireProduct()
{
    try
    {     
            List<Product> products = lisProducts.ToList();
            foreach (Product p in products)
            {


                DateTime date2 = p.ExpirationDate;
                DateTime date1 = DateTime.Now;
                TimeSpan t = date2.Subtract(date1);
                if (t.Days < 0)
                {
                    p.Quantity = p.Quantity - 1;
                    Console.WriteLine(p.ProductName + " remove from the refrigerator");
                }
            }
      
    }
    catch(Exception ex)
    {
        Console.WriteLine(ex.Message);
    }

}
